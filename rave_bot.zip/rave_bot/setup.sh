#!/usr/bin/env bash
# Установка бота (запускать один раз): bash setup.sh
set -e
cd "$(dirname "$0")"
python3 -m venv venv
. venv/bin/activate
pip install -q -r requirements.txt
sudo "$PWD/venv/bin/playwright" install-deps chromium
playwright install chromium
[ -f .env ] || cp .env.example .env
echo
echo "Готово. Теперь откройте файл .env, заполните его, затем: bash start.sh"
