# Rave bot на Oracle Cloud (Always Free)

## 1. Первый вход локально (капча / 2FA)
На своём компьютере:
    pip install -r requirements.txt && playwright install chromium
    cp .env.example .env   # заполнить, HEADLESS=0
    python bot.py          # войти вручную, убедиться, что сессия сохранилась
Появится папка `profile`.

## 2. Сервер Oracle
1. Зарегистрируйтесь на cloud.oracle.com (нужна банковская карта для проверки).
2. Compute -> Create instance: Ubuntu 24.04, shape VM.Standard.A1.Flex,
   2 OCPU / 12 GB (не больше). Скачайте SSH-ключ.
   Если "Out of host capacity" - попробуйте другой availability domain или позже.
   Micro-вариант (1 GB) для Chromium слишком слабый.

## 3. Установка на сервере
    ssh -i key ubuntu@<IP>
    sudo apt update && sudo apt install -y python3-venv
    # с вашего компьютера: scp -i key -r rave_bot ubuntu@<IP>:~
    cd ~/rave_bot
    python3 -m venv venv && source venv/bin/activate
    pip install -r requirements.txt
    playwright install --with-deps chromium
    nano .env              # HEADLESS=1, TELEGRAM_TOKEN, ALLOWED_USER_ID

## 4. Автозапуск
    sudo cp rave-bot.service /etc/systemd/system/
    sudo systemctl enable --now rave-bot
    sudo journalctl -u rave-bot -f    # логи

## 5. Telegram
Токен - у @BotFather, свой ID - у @userinfobot.
Команды: /join <ссылка>, /say <текст>, /leave, /status, /screenshot
