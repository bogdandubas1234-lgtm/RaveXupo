#!/usr/bin/env bash
# Запуск бота в фоне: bash start.sh
cd "$(dirname "$0")"
. venv/bin/activate
pkill -f controller.py 2>/dev/null || true
nohup python controller.py > bot.log 2>&1 &
sleep 5
echo "--- bot.log ---"
tail -n 20 bot.log
