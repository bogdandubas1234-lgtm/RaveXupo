"""
Управление Rave-ботом через Telegram.

Команды (только для ALLOWED_USER_ID):
  /join <ссылка>  - зайти в рум
  /say <текст>    - написать в чат рума
  /leave          - выйти из рума
  /status         - где бот сейчас
  /screenshot     - скриншот страницы (удобно для подбора селекторов)
  /html [ссылка]  - открыть страницу без входа, прислать HTML и скриншот
  /click <css>    - кликнуть по элементу
  /fill <css> | <текст> - ввести текст в поле
"""
import asyncio
import io
import os

from dotenv import load_dotenv
from playwright.async_api import TimeoutError as PWTimeout
from playwright.async_api import async_playwright
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from bot import EMAIL, HEADLESS, LOGIN_URL, PASSWORD, POLL_SECONDS
from bot import PROFILE_DIR, SELECTORS, match_command

load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN", "")
ALLOWED_USER_ID = int(os.getenv("ALLOWED_USER_ID", "0"))

state = {"pw": None, "context": None, "page": None, "task": None, "room": None}


def allowed(update: Update) -> bool:
    user = update.effective_user
    return bool(user) and user.id == ALLOWED_USER_ID


async def ensure_browser(do_login=True):
    if state["context"]:
        return
    state["pw"] = await async_playwright().start()
    state["context"] = await state["pw"].chromium.launch_persistent_context(
        PROFILE_DIR, headless=HEADLESS
    )
    pages = state["context"].pages
    state["page"] = pages[0] if pages else await state["context"].new_page()
    if do_login:
        await login(state["page"])


async def login(page):
    await page.goto(LOGIN_URL)
    try:
        await page.wait_for_selector(SELECTORS["logged_in_marker"], timeout=5000)
        return
    except PWTimeout:
        pass
    await page.fill(SELECTORS["email_input"], EMAIL)
    await page.fill(SELECTORS["password_input"], PASSWORD)
    await page.click(SELECTORS["login_button"])
    await page.wait_for_selector(SELECTORS["logged_in_marker"], timeout=60_000)


async def watch_chat(page):
    seen = len(await page.query_selector_all(SELECTORS["chat_messages"]))
    while True:
        messages = await page.query_selector_all(SELECTORS["chat_messages"])
        for msg in messages[seen:]:
            reply = match_command((await msg.inner_text()) or "")
            if reply:
                await send(page, reply)
        seen = len(messages)
        await asyncio.sleep(POLL_SECONDS)


async def send(page, text):
    await page.fill(SELECTORS["chat_input"], text)
    await page.click(SELECTORS["chat_send"])


async def stop_task():
    if state["task"]:
        state["task"].cancel()
        state["task"] = None


async def cmd_join(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    if not ctx.args:
        await update.message.reply_text("Использование: /join <ссылка>")
        return
    url = ctx.args[0]
    await update.message.reply_text("Захожу...")
    try:
        await ensure_browser()
        await stop_task()
        await state["page"].goto(url)
        await state["page"].wait_for_load_state("networkidle")
        state["room"] = url
        state["task"] = asyncio.create_task(watch_chat(state["page"]))
        await update.message.reply_text("Я в руме.")
    except Exception as e:  # noqa: BLE001
        await update.message.reply_text(f"Ошибка: {e}")


async def cmd_say(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update) or not state["room"]:
        return
    text = " ".join(ctx.args)
    if not text:
        await update.message.reply_text("Использование: /say <текст>")
        return
    try:
        await send(state["page"], text)
        await update.message.reply_text("Отправлено.")
    except Exception as e:  # noqa: BLE001
        await update.message.reply_text(f"Ошибка: {e}")


async def cmd_leave(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    await stop_task()
    if state["page"]:
        await state["page"].goto("about:blank")
    state["room"] = None
    await update.message.reply_text("Вышел из рума.")


async def cmd_status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    room = state["room"] or "ни в каком руме"
    await update.message.reply_text(f"Сейчас: {room}")


async def cmd_screenshot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not allowed(update) or not state["page"]:
        return
    png = await state["page"].screenshot()
    await update.message.reply_photo(io.BytesIO(png))


async def cmd_html(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """/html [ссылка] - открыть страницу (без входа) и прислать HTML + скриншот."""
    if not allowed(update):
        return
    try:
        await ensure_browser(do_login=False)
        page = state["page"]
        if ctx.args:
            await page.goto(ctx.args[0])
            await page.wait_for_load_state("networkidle")
        html = await page.content()
        await update.message.reply_document(
            io.BytesIO(html.encode("utf-8")), filename="page.html"
        )
        await update.message.reply_photo(io.BytesIO(await page.screenshot()))
    except Exception as e:  # noqa: BLE001
        await update.message.reply_text(f"Ошибка: {e}")


async def cmd_click(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """/click <селектор> - кликнуть по элементу."""
    if not allowed(update) or not ctx.args:
        return
    try:
        await ensure_browser(do_login=False)
        await state["page"].click(" ".join(ctx.args), timeout=10_000)
        await update.message.reply_text("Клик выполнен. Пришлите /html")
    except Exception as e:  # noqa: BLE001
        await update.message.reply_text(f"Ошибка: {e}")


async def cmd_fill(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """/fill <селектор> | <текст> - ввести текст в поле."""
    if not allowed(update):
        return
    raw = update.message.text.partition(" ")[2]
    sel, sep, text = raw.partition("|")
    if not sep:
        await update.message.reply_text("Использование: /fill селектор | текст")
        return
    try:
        await ensure_browser(do_login=False)
        await state["page"].fill(sel.strip(), text.strip(), timeout=10_000)
        await update.message.reply_text("Введено. Пришлите /html")
    except Exception as e:  # noqa: BLE001
        await update.message.reply_text(f"Ошибка: {e}")


def main():
    if not TOKEN or not ALLOWED_USER_ID:
        raise SystemExit("Укажите TELEGRAM_TOKEN и ALLOWED_USER_ID в .env")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("join", cmd_join))
    app.add_handler(CommandHandler("say", cmd_say))
    app.add_handler(CommandHandler("leave", cmd_leave))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("screenshot", cmd_screenshot))
    app.add_handler(CommandHandler("html", cmd_html))
    app.add_handler(CommandHandler("click", cmd_click))
    app.add_handler(CommandHandler("fill", cmd_fill))
    app.run_polling()


if __name__ == "__main__":
    main()
