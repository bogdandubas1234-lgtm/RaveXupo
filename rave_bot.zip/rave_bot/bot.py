"""
Каркас бота для входа в Rave-комнату через браузер (Playwright).

ВАЖНО: селекторы в SELECTORS — заглушки. Их нужно заменить на реальные
со страницы Rave (ПКМ -> Inspect -> Copy -> Copy selector).
"""
import os
import sys
import time

from dotenv import load_dotenv
from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright

load_dotenv()

EMAIL = os.getenv("RAVE_EMAIL", "")
PASSWORD = os.getenv("RAVE_PASSWORD", "")
LOGIN_URL = os.getenv("RAVE_LOGIN_URL", "")  # страница входа веб-версии Rave
ROOM_URL = os.getenv("RAVE_ROOM_URL", "https://rave.link/k1D4LQu")
HEADLESS = os.getenv("HEADLESS", "0") == "1"
PROFILE_DIR = os.getenv("PROFILE_DIR", "./profile")  # тут хранится сессия
POLL_SECONDS = float(os.getenv("POLL_SECONDS", "2"))

# TODO: заменить на реальные селекторы
SELECTORS = {
    "email_input": 'input[type="email"]',
    "password_input": 'input[type="password"]',
    "login_button": 'button[type="submit"]',
    "logged_in_marker": "TODO_SELECTOR_THAT_EXISTS_ONLY_WHEN_LOGGED_IN",
    "chat_messages": "TODO_SELECTOR_FOR_ALL_CHAT_MESSAGES",
    "chat_input": "TODO_SELECTOR_FOR_CHAT_INPUT",
    "chat_send": "TODO_SELECTOR_FOR_SEND_BUTTON",
}

# Простые команды: сообщение -> ответ
COMMANDS = {
    "!ping": "pong",
    "!help": "Команды: !ping, !help",
}


def match_command(text: str):
    """Ответ на команду, если ПОСЛЕДНЯЯ строка сообщения начинается с команды.
    Так бот не реагирует на собственные ответы (в них команды не в начале)."""
    lines = text.strip().lower().splitlines()
    if not lines or not lines[-1].split():
        return None
    return COMMANDS.get(lines[-1].split()[0])


def is_logged_in(page) -> bool:
    try:
        page.wait_for_selector(SELECTORS["logged_in_marker"], timeout=5000)
        return True
    except PWTimeout:
        return False


def login(page) -> None:
    if not LOGIN_URL:
        sys.exit("Укажите RAVE_LOGIN_URL в .env")
    page.goto(LOGIN_URL)
    if is_logged_in(page):
        print("Сессия уже активна, вход не нужен.")
        return
    if not EMAIL or not PASSWORD:
        sys.exit("Укажите RAVE_EMAIL и RAVE_PASSWORD в .env")
    page.fill(SELECTORS["email_input"], EMAIL)
    page.fill(SELECTORS["password_input"], PASSWORD)
    page.click(SELECTORS["login_button"])
    # Если появится капча или 2FA — пройдите вручную в открытом окне.
    print("Жду завершения входа (до 2 минут)...")
    page.wait_for_selector(SELECTORS["logged_in_marker"], timeout=120_000)
    print("Вход выполнен.")


def send_message(page, text: str) -> None:
    page.fill(SELECTORS["chat_input"], text)
    page.click(SELECTORS["chat_send"])


def chat_loop(page) -> None:
    seen = len(page.query_selector_all(SELECTORS["chat_messages"]))
    print("Бот в комнате. Ctrl+C для выхода.")
    while True:
        messages = page.query_selector_all(SELECTORS["chat_messages"])
        for msg in messages[seen:]:
            reply = match_command(msg.inner_text() or "")
            if reply:
                send_message(page, reply)
        seen = len(messages)
        time.sleep(POLL_SECONDS)


def main() -> None:
    with sync_playwright() as p:
        # persistent context сохраняет cookies, повторный вход не нужен
        context = p.chromium.launch_persistent_context(
            PROFILE_DIR, headless=HEADLESS
        )
        page = context.pages[0] if context.pages else context.new_page()
        login(page)
        page.goto(ROOM_URL)
        page.wait_for_load_state("networkidle")
        try:
            chat_loop(page)
        except KeyboardInterrupt:
            print("Выход.")
        finally:
            context.close()


if __name__ == "__main__":
    main()
